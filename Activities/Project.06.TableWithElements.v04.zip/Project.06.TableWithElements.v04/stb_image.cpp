#define STB_IMAGE_IMPLEMENTATION
#define STBI_FAILURE_USERMSG // optional
#include "3rdparty/stb_image.h"
