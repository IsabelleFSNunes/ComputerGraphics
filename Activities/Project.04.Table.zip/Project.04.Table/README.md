# Project 04 - Simple Table

First project simplified. 

## Example of execution
![P04.01](../../imgs/Project04_img01.JPG)